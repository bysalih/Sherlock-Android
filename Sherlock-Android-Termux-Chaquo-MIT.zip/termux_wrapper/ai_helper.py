# ai_helper.py - simple AI commentary (replace with API calls if needed)
def ask_ai_about_username(username):
    # Small, local heuristic + example responses to avoid embedding API keys
    common_hints = {
        'admin': 'Common admin-like username; often placeholder or shared account.',
        'john': 'Very common name; many accounts will exist with variations.',
        'x': 'Short usernames often taken; low chance of uniqueness.'
    }
    for k, v in common_hints.items():
        if k in username.lower():
            return v
    return f'No obvious red flags for "{username}". Use manual verification for sensitive cases.'