#!/usr/bin/env python3
# main.py - Termux wrapper entrypoint
from sherlock_wrapper import SherlockWrapper
from ai_helper import ask_ai_about_username
import argparse
import sys

def cli():
    parser = argparse.ArgumentParser(description="Sherlock Termux wrapper")
    parser.add_argument("username", nargs='?', help="username to search")
    parser.add_argument("--voice", action="store_true", help="Use Vosk voice input (if configured)")
    args = parser.parse_args()

    sw = SherlockWrapper()
    if args.voice:
        print("[*] Starting voice listening (Vosk)...")
        username = sw.listen_for_username()
        if not username:
            print("No voice input detected.")
            sys.exit(1)
    else:
        username = args.username or input("Enter username to search: ").strip()

    print(f"Searching for: {username}")
    results = sw.search(username)
    for site, link in results.items():
        status = "FOUND" if link else "NOT FOUND"
        print(f"{site}: {status} -> {link}")

    print("\n[AI ANALYSIS]")
    print(ask_ai_about_username(username))

if __name__ == '__main__':
    cli()