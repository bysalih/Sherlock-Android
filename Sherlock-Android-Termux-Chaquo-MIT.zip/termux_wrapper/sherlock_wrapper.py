# sherlock_wrapper.py
# Minimal wrapper adapting Sherlock-like username checks for Android/Termux.
import requests
import json
import os

class SherlockWrapper:
    def __init__(self):
        # trimmed list optimized for mobile (lightweight check)
        self.sites = {
            "GitHub": "https://github.com/{}",
            "Twitter": "https://twitter.com/{}",
            "Instagram": "https://www.instagram.com/{}",
            "Reddit": "https://www.reddit.com/user/{}",
            "LinkedIn": "https://www.linkedin.com/in/{}"
        }
        # timeouts to reduce memory/time on mobile
        self.timeout = 6

    def search(self, username):
        results = {}
        headers = {'User-Agent': 'Mozilla/5.0 (Android; Mobile) Sherlock/1.0'}
        for name, pattern in self.sites.items():
            try:
                url = pattern.format(username)
                r = requests.head(url, headers=headers, allow_redirects=True, timeout=self.timeout)
                if r.status_code == 200:
                    results[name] = url
                else:
                    # some sites block HEAD; fall back to GET lightly
                    r2 = requests.get(url, headers=headers, timeout=self.timeout)
                    results[name] = url if r2.status_code == 200 else None
            except Exception:
                results[name] = None
        return results

    def listen_for_username(self):
        # Lightweight wrapper to call Vosk or other local STT. Tries to import vosk if available.
        try:
            from vosk_stub import listen_once
            return listen_once()
        except Exception as e:
            print("Voice subsystem not available:", e)
            return None