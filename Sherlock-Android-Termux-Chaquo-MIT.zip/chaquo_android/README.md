Chaquo Android scaffold.
Open this folder in Android Studio with Chaquo/Chaquopy plugin installed.
Place the content of `termux_wrapper` and `kivy_gui` into `app/src/main/python/` or use Gradle packaging to include them.
See instructions in README.md for packaging steps.