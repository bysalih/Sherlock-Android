# BeeWare / Briefcase notes
- BeeWare/Briefcase can package Python apps into native Android apps, but requires a Linux/macOS build host.
- Install briefcase and follow documentation: https://briefcase.readthedocs.io/
- Brief steps:
  1. pip install briefcase
  2. briefcase create android
  3. briefcase build android
  4. briefcase run android -d <device>
- Note: Kivy support via Briefcase is less straightforward; consider using BeeWare for Toga apps or use buildozer for Kivy.