# Sherlock-Android-Termux-Chaquo
**Project skeleton** that ports the Sherlock Python username-check tool to Android (Termux) and provides scaffolding
to package as an APK using Chaquo or BeeWare. Includes Termux install scripts, modified Sherlock wrapper, Kivy GUI,
voice-interface stubs (Vosk / SpeechRecognition), ARM optimization notes, and Gradle/Chaquo scaffold.

**What this repo contains**
- `termux_install.sh` : automated installer for Termux (packages + python venv + clone)
- `termux_wrapper/` : Python project runnable inside Termux (main.py, sherlock_wrapper.py, ai_helper.py)
- `kivy_gui/` : Kivy GUI frontend that calls the sherlock wrapper
- `vosk_stubs/` : Vosk integration example + model download helper
- `chaquo_android/` : Android Studio + Chaquopy/Chaquo scaffold (Gradle files + instructions)
- `beeweare_notes/` : Notes + brief scripts for BeeWare/Briefcase packaging alternative
- `requirements-termux.txt` : pip packages for Termux
- `pydroid_requirements.txt` : for Pydroid users
- `README.md` : this file

**Important**
- This is a **source skeleton**. It does NOT contain a compiled APK.
- You can build an APK from `chaquo_android/` in Android Studio (machine required).
- The Termux scripts will run on Android Termux; Chaquo scaffolding runs in Android Studio on desktop.