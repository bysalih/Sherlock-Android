# ARM & Low-memory Optimization Notes

1. Use HEAD requests first (faster) and fall back to GET only if necessary.
2. Use small site list on mobile; allow users to enable extended lists.
3. Set short timeouts (3-6s) to avoid long waits.
4. Use streaming responses where possible; avoid loading large pages.
5. Use Python's built-in cache (shelve) to store recent results and reduce network calls.
6. For Vosk, use small model (e.g., vosk-model-small-ru-0.22) to save space.
7. Test on ARMv7 and ARM64 devices; compile any C extensions for target ABI.
8. Minimize dependencies; avoid heavy libs that require building large wheels.