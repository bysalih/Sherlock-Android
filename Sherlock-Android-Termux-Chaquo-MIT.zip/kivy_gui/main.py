from kivy.app import App
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.textinput import TextInput
from kivy.uix.button import Button
from kivy.uix.label import Label
from termux_wrapper.sherlock_wrapper import SherlockWrapper
from termux_wrapper.ai_helper import ask_ai_about_username

class Gui(BoxLayout):
    def __init__(self, **kwargs):
        super().__init__(orientation='vertical', **kwargs)
        self.input = TextInput(hint_text='Enter username', multiline=False)
        self.search_btn = Button(text='Search', size_hint=(1, 0.15))
        self.voice_btn = Button(text='🎤 Voice', size_hint=(1,0.15))
        self.output = Label(text='Results will appear here', valign='top')
        self.search_btn.bind(on_press=self.on_search)
        self.voice_btn.bind(on_press=self.on_voice)
        self.add_widget(self.input)
        self.add_widget(self.search_btn)
        self.add_widget(self.voice_btn)
        self.add_widget(self.output)
        self.sw = SherlockWrapper()

    def on_search(self, instance):
        username = self.input.text.strip()
        if not username:
            self.output.text = "Enter a username"
            return
        results = self.sw.search(username)
        out = []
        for k,v in results.items():
            out.append(f"{k}: {'FOUND' if v else 'NOT'}")
        self.output.text = "\n".join(out) + "\n\n" + ask_ai_about_username(username)

    def on_voice(self, instance):
        username = self.sw.listen_for_username()
        if username:
            self.input.text = username
            self.on_search(None)
        else:
            self.output.text = "Voice input not available"

class SherlockApp(App):
    def build(self):
        return Gui()

if __name__ == '__main__':
    SherlockApp().run()