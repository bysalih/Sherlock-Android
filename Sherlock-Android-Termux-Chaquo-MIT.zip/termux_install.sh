#!/data/data/com.termux/files/usr/bin/bash
# termux_install.sh
# Run inside Termux on Android.
set -e
echo "[*] Updating packages..."
pkg update -y
pkg upgrade -y

echo "[*] Installing required packages..."
pkg install -y python git wget proot pulseaudio
pkg install -y clang make openssl-tool libffi-dev

echo "[*] Creating python venv..."
python -m pip install --upgrade pip
pip install virtualenv
python -m virtualenv sherlock_venv
source sherlock_venv/bin/activate

echo "[*] Installing python requirements..."
pip install -r requirements-termux.txt

echo "[*] Cloning repository (if not present)..."
if [ ! -d "sherlock_project" ]; then
    git clone https://github.com/USERNAME/REPO.git sherlock_project || true
fi

echo "[*] Done. To run the app in Termux:"
echo "  source sherlock_venv/bin/activate"
echo "  python sherlock_project/termux_wrapper/main.py"

# Note: Microphone access on Termux may require 'termux-api' and special permissions.