# vosk_stub.py - minimal example using Vosk offline model
# Requires: pip install vosk sounddevice
def listen_once(model_path='model'):
    try:
        from vosk import Model, KaldiRecognizer
        import sounddevice as sd
        import json, sys, queue, os, tempfile

        if not os.path.exists(model_path):
            print("Vosk model not found. Download a small model and place it in 'model/'")
            return None

        model = Model(model_path)
        rec = KaldiRecognizer(model, 16000)
        q = queue.Queue()

        def callback(indata, frames, time, status):
            q.put(bytes(indata))

        with sd.RawInputStream(samplerate=16000, blocksize = 8000, dtype='int16',
                              channels=1, callback=callback):
            print("Listening (press Ctrl+C to stop)...")
            while True:
                data = q.get()
                if rec.AcceptWaveform(data):
                    res = json.loads(rec.Result())
                    text = res.get('text','').strip()
                    if text:
                        return text
    except Exception as e:
        print("Vosk listen error:", e)
        return None