package com.example.sherlock;

import android.content.Context;
import com.chaquo.python.Python;
import com.chaquo.python.android.AndroidPlatform;

public class AndroidPlatform extends AndroidPlatform {
    public AndroidPlatform(Context appContext) {
        super(appContext);
    }
}
