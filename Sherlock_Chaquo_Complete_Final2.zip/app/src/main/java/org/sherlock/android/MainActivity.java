package org.sherlock.android;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import com.chaquo.python.Python;
import com.chaquo.python.android.AndroidPlatform;

public class MainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (!Python.isStarted()) {
            Python.start(new AndroidPlatform(this));
        }
        try {
            Python.getInstance().getModule("app_main").callAttr("main_entry");
        } catch (Exception e) {
            e.printStackTrace();
        }
        finish();
    }
}
