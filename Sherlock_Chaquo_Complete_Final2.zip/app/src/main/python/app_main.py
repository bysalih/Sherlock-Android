def main_entry():
    from kivy_gui.main import run_kivy_app
    run_kivy_app()
