import requests

def ask_ai_about_username(username):
    if 'admin' in username.lower():
        return 'Common admin-like username; often placeholder.'
    return f'No immediate red flags for {username}.'

class SherlockWrapper:
    def __init__(self):
        self.sites = {
            'GitHub': 'https://github.com/{}',
            'Twitter': 'https://twitter.com/{}',
            'Instagram': 'https://www.instagram.com/{}',
            'Reddit': 'https://www.reddit.com/user/{}'
        }
        self.timeout = 6

    def search(self, username):
        results = {}
        headers = {'User-Agent': 'Mozilla/5.0 (Android; Mobile) Sherlock/1.0'}
        for name, pattern in self.sites.items():
            try:
                url = pattern.format(username)
                r = requests.head(url, headers=headers, allow_redirects=True, timeout=self.timeout)
                if r.status_code == 200:
                    results[name] = url
                else:
                    r2 = requests.get(url, headers=headers, timeout=self.timeout)
                    results[name] = url if r2.status_code == 200 else None
            except Exception:
                results[name] = None
        return results
