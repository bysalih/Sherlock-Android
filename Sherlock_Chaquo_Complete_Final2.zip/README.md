# Sherlock Android Chaquo Final

Tam yapılandırılmış, gerçek Gradle Wrapper ve Chaquo Python plugin ile.
